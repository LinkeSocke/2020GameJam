Game Name: Bodybuilder Blackout

Team Name: Linke Socke

Teammembers:
- Mario Kerndler
- Moritz Großfurtner
- David Holy
- Maria Raser

Description:

The bodybuilder and artist pair Igor and Anastasia are trying to fix their fusebox in the dark without destroying their entire home.
This game is intended as a co-op experience where communication is key! 
One player controls the game while the other has to guide them using the included document.
 The goal of the controlling player is to navigate a dark house and reach the goal while 
trying not to break anything and also describing the environment to the advising player. 
The goal of the advising player is to communicate with the controlling player, 
warn them of any breakable objects they might encounter, and help them solve small puzzles.
 Both players have to communicate with each other to succesfully make it through the game. 
 For the intended experience it is reccomended that the advising player doesn’t look at the game screen during gameplay.

Controls:

WASD - Walk, Crouch, Jump
Space - Jump
Mouse - Look around
F - Interact